export enum ToolType {
  TEXT_TO_IMAGE = 'TEXT_TO_IMAGE',
  YOUTUBE_SEO = 'YOUTUBE_SEO',
  VIRAL_HASHTAGS = 'VIRAL_HASHTAGS'
}

export enum AspectRatio {
  RATIO_16_9 = '16:9',
  RATIO_9_16 = '9:16',
  RATIO_4_5 = '4:5',
  RATIO_1_1 = '1:1',
  RATIO_4_3 = '4:3'
}

export type HashtagPlatform = 
  | 'Instagram' 
  | 'TikTok' 
  | 'YouTube' 
  | 'Facebook' 
  | 'Twitter (X)' 
  | 'Threads' 
  | 'LinkedIn' 
  | 'Pinterest' 
  | 'Snapchat';

export type SeoPlatform = 
  | 'YouTube' 
  | 'TikTok' 
  | 'Instagram' 
  | 'Website / Blog' 
  | 'E-commerce' 
  | 'Podcast' 
  | 'Facebook Pages';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // In a real app, never store plain text
  avatar?: string;
  createdAt: number;
}

export interface UsageData {
  date: string; // YYYY-MM-DD
  counts: Record<ToolType, number>;
}

export interface HistoryItem {
  id: string;
  userId: string;
  tool: ToolType;
  prompt: string;
  result: any; // Can be image URLs, SEO objects, or hashtag lists
  options?: any; // Like aspect ratio, reference image, or platform
  timestamp: number;
}

export interface SEOResult {
  title: string;
  description: string;
  tags: string[];
}

export interface AppSettings {
  userId: string;
  theme: 'light' | 'dark';
}

export const LIMITS: Record<ToolType, number> = {
  [ToolType.TEXT_TO_IMAGE]: 50,
  [ToolType.YOUTUBE_SEO]: 10,
  [ToolType.VIRAL_HASHTAGS]: 10
};
