import { HistoryItem } from '../types';

const DB_NAME = 'NebulaDB';
const DB_VERSION = 2; // Bumped version to force schema update
const STORE_NAME = 'history';

let dbInstance: IDBDatabase | null = null;

// Initialize Database
export const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = (event) => {
      console.error("IndexedDB error:", event);
      reject("Failed to open database");
    };

    request.onsuccess = (event) => {
      dbInstance = (event.target as IDBOpenDBRequest).result;
      resolve(dbInstance);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // If store exists from v1, delete it to ensure v2 schema (correct keyPath) is applied
      if (db.objectStoreNames.contains(STORE_NAME)) {
        db.deleteObjectStore(STORE_NAME);
      }

      const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      store.createIndex('userId', 'userId', { unique: false });
      store.createIndex('timestamp', 'timestamp', { unique: false });
    };
  });
};

// Add Item with Auto-Cleanup
export const addHistoryToDB = async (item: HistoryItem): Promise<void> => {
  const db = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);

    store.put(item);

    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject("Failed to save to DB");
  });
};

// Get All History for User
export const getHistoryFromDB = async (userId: string): Promise<HistoryItem[]> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STORE_NAME], 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const index = store.index('userId');
    const request = index.getAll(userId);

    request.onsuccess = () => {
      const results = request.result as HistoryItem[];
      // Sort by timestamp desc (newest first)
      if (results) {
        results.sort((a, b) => b.timestamp - a.timestamp);
      }
      resolve(results || []);
    };

    request.onerror = () => reject("Failed to fetch history");
  });
};

// Delete Item - Strictly ensures transaction completes
export const deleteHistoryFromDB = async (id: string): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    
    // Check if item exists (optional but good for debugging)
    // Then perform delete
    const request = store.delete(id);

    request.onsuccess = () => {
       // Request initiated
    };

    // Handle request errors
    request.onerror = (e) => {
      console.error("Delete request failed:", e);
      reject("Could not delete item");
    };

    // Wait for transaction to complete to ensure data is actually gone
    transaction.oncomplete = () => {
      resolve();
    };
    
    transaction.onerror = (event) => {
      console.error("Delete transaction error:", event);
      reject("Failed to commit delete transaction");
    };
  });
};

// Clear All History for User
export const clearHistoryFromDB = async (userId: string): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const index = store.index('userId');
    const request = index.openCursor(IDBKeyRange.only(userId));

    request.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest).result as IDBCursorWithValue;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
    
    request.onerror = (e) => {
      console.error("Cursor request failed:", e);
    };

    transaction.oncomplete = () => {
      resolve();
    };
    
    transaction.onerror = (event) => {
      console.error("Clear all transaction failed:", event);
      reject("Failed to clear history");
    };
  });
};

// Migration Tool: LocalStorage -> IndexedDB
export const migrateLocalStorageToDB = async (userId: string) => {
  const LS_KEY = 'nebula_history';
  const raw = localStorage.getItem(LS_KEY);
  if (raw) {
    try {
      const items: HistoryItem[] = JSON.parse(raw);
      const userItems = items.filter(i => i.userId === userId);
      
      if (userItems.length > 0) {
        const db = await initDB();
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        
        userItems.forEach(item => {
          store.put(item);
        });
        
        transaction.oncomplete = () => {
          localStorage.removeItem(LS_KEY); 
        };
      } else {
         localStorage.removeItem(LS_KEY); 
      }
    } catch (e) {
      console.error("Migration failed", e);
    }
  }
};