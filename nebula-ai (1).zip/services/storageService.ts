import { User, HistoryItem, ToolType, UsageData, LIMITS, AppSettings } from '../types';
import { addHistoryToDB, getHistoryFromDB, deleteHistoryFromDB, migrateLocalStorageToDB, clearHistoryFromDB } from './db';

const KEYS = {
  USERS: 'nebula_users',
  CURRENT_USER: 'nebula_current_user',
  // HISTORY: 'nebula_history', // DEPRECATED in favor of IndexedDB
  USAGE: 'nebula_usage',
  SETTINGS: 'nebula_settings',
  SESSION_META: 'nebula_session_meta'
};

const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 Days
const MAX_HISTORY_ITEMS = 50; 

// --- Helper Functions ---
const hashPassword = (password: string): string => {
  let hash = 0;
  const str = password + "nebula_salt_v1";
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16);
};

const normalizeEmail = (email: string): string => {
  return email.toLowerCase().trim();
};

const safeSetItem = (key: string, value: string) => {
  try {
    localStorage.setItem(key, value);
  } catch (e: any) {
    if (e.name === 'QuotaExceededError' || e.code === 22) {
      console.error("LocalStorage quota exceeded. Cannot save metadata.");
      alert("Browser storage is full. Please clear your cache or delete some settings.");
    }
  }
};

// --- User Management ---

export const getUsers = (): User[] => {
  try {
    const users = localStorage.getItem(KEYS.USERS);
    return users ? JSON.parse(users) : [];
  } catch (e) {
    return [];
  }
};

export const saveUser = (user: User): void => {
  const users = getUsers();
  const cleanEmail = normalizeEmail(user.email);
  
  const existingIndex = users.findIndex(u => normalizeEmail(u.email) === cleanEmail);
  
  const secureUser = {
    ...user,
    email: cleanEmail,
    password: user.password ? hashPassword(user.password) : undefined
  };

  if (existingIndex > -1) {
    users[existingIndex] = { ...users[existingIndex], ...secureUser };
  } else {
    users.push(secureUser);
  }
  
  safeSetItem(KEYS.USERS, JSON.stringify(users));
};

export const loginUser = (email: string, password: string): User | null => {
  const users = getUsers();
  const cleanEmail = normalizeEmail(email);
  const hashedPassword = hashPassword(password);

  const user = users.find(u => normalizeEmail(u.email) === cleanEmail && u.password === hashedPassword);
  
  if (user) {
    safeSetItem(KEYS.CURRENT_USER, JSON.stringify(user));
    updateSessionActivity();
    
    // Trigger Migration in background on login
    migrateLocalStorageToDB(user.id).catch(console.error);
    
    return user;
  }
  return null;
};

export const updateSessionActivity = (): void => {
  const now = Date.now();
  safeSetItem(KEYS.SESSION_META, now.toString());
};

export const getCurrentUser = (): User | null => {
  try {
    const userStr = localStorage.getItem(KEYS.CURRENT_USER);
    const lastActiveStr = localStorage.getItem(KEYS.SESSION_META);
    
    if (!userStr || !lastActiveStr) {
      logoutUser();
      return null;
    }

    const lastActive = parseInt(lastActiveStr, 10);
    const now = Date.now();

    if (now - lastActive > SESSION_DURATION) {
      logoutUser();
      return null;
    }

    updateSessionActivity();
    return JSON.parse(userStr);
  } catch (e) {
    logoutUser();
    return null;
  }
};

export const logoutUser = (): void => {
  localStorage.removeItem(KEYS.CURRENT_USER);
  localStorage.removeItem(KEYS.SESSION_META);
};

// --- History Management (Async / IndexedDB) ---

export const getHistory = async (userId: string): Promise<HistoryItem[]> => {
  try {
    return await getHistoryFromDB(userId);
  } catch (e) {
    console.error("Failed to load history", e);
    return [];
  }
};

export const saveHistoryItem = async (item: HistoryItem): Promise<void> => {
  try {
    await addHistoryToDB(item);
  } catch (error) {
    console.error("Failed to save history item to DB", error);
    throw error;
  }
};

export const deleteHistoryItem = async (id: string): Promise<void> => {
  await deleteHistoryFromDB(id);
};

export const clearUserHistory = async (userId: string): Promise<void> => {
  await clearHistoryFromDB(userId);
};

// --- Usage Limits (Sync / LocalStorage) ---

const getTodayString = (): string => {
  return new Date().toISOString().split('T')[0];
};

export const getUsage = (userId: string): UsageData => {
  const usageStore = localStorage.getItem(KEYS.USAGE);
  const allUsage: Record<string, UsageData> = usageStore ? JSON.parse(usageStore) : {};
  const today = getTodayString();
  const key = `${userId}_${today}`;
  
  if (!allUsage[key]) {
    return { date: today, counts: { [ToolType.TEXT_TO_IMAGE]: 0, [ToolType.YOUTUBE_SEO]: 0, [ToolType.VIRAL_HASHTAGS]: 0 } };
  }
  return allUsage[key];
};

export const checkLimit = (userId: string, tool: ToolType): boolean => {
  const usage = getUsage(userId);
  return usage.counts[tool] < LIMITS[tool];
};

export const incrementUsage = (userId: string, tool: ToolType): void => {
  const usageStore = localStorage.getItem(KEYS.USAGE);
  const allUsage: Record<string, UsageData> = usageStore ? JSON.parse(usageStore) : {};
  const today = getTodayString();
  const key = `${userId}_${today}`;

  if (!allUsage[key]) {
    allUsage[key] = { date: today, counts: { [ToolType.TEXT_TO_IMAGE]: 0, [ToolType.YOUTUBE_SEO]: 0, [ToolType.VIRAL_HASHTAGS]: 0 } };
  }
  
  allUsage[key].counts[tool]++;
  safeSetItem(KEYS.USAGE, JSON.stringify(allUsage));
};

// --- Settings (Sync / LocalStorage) ---
export const getSettings = (userId: string): AppSettings => {
    const settings = localStorage.getItem(KEYS.SETTINGS);
    const allSettings: Record<string, AppSettings> = settings ? JSON.parse(settings) : {};
    return allSettings[userId] || { userId, theme: 'light' };
}

export const saveSettings = (settings: AppSettings): void => {
    const store = localStorage.getItem(KEYS.SETTINGS);
    const allSettings: Record<string, AppSettings> = store ? JSON.parse(store) : {};
    allSettings[settings.userId] = settings;
    safeSetItem(KEYS.SETTINGS, JSON.stringify(allSettings));
}