import { GoogleGenAI, Type } from "@google/genai";
import { AspectRatio, SEOResult, HashtagPlatform, SeoPlatform } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateImages = async (prompt: string, aspectRatio: AspectRatio, referenceImageBase64?: string): Promise<string[]> => {
  const ai = getAI();
  const model = "gemini-2.5-flash-image"; 
  
  const parts: any[] = [];
  
  if (referenceImageBase64) {
    // Issue 1 Fix: Explicit instruction to use image as style reference
    const stylePrompt = `Generate an image based on this description: "${prompt}".\n\nCRITICAL INSTRUCTION: You must strictly mimic the visual style, art direction, color palette, lighting, mood, and composition of the provided reference image. The output should look like it belongs to the exact same series or artist as the reference image.`;
    
    parts.push({ text: stylePrompt });

    const base64Data = referenceImageBase64.includes('base64,') 
      ? referenceImageBase64.split('base64,')[1] 
      : referenceImageBase64;
      
    parts.push({
      inlineData: {
        data: base64Data,
        mimeType: 'image/jpeg' 
      }
    });
  } else {
    parts.push({ text: prompt });
  }
  
  const request = async () => {
    const response = await ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio
        }
      }
    });

    const candidates = response.candidates;
    if (!candidates || candidates.length === 0) throw new Error("No image generated");
    
    const contentParts = candidates[0].content.parts;
    const imagePart = contentParts.find(p => p.inlineData);
    
    if (imagePart && imagePart.inlineData) {
        return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
    }
    throw new Error("No image data found in response");
  };

  try {
    const results = await Promise.all([request(), request()]);
    return results;
  } catch (error) {
    console.error("Image generation failed:", error);
    throw error;
  }
};

export const generateSEO = async (prompt: string, platform: SeoPlatform): Promise<SEOResult[]> => {
  const ai = getAI();
  const model = "gemini-3-flash-preview";

  const response = await ai.models.generateContent({
    model,
    contents: `Generate 2 distinct SEO suggestions for ${platform} content about: "${prompt}".
    Optimize specifically for the ${platform} algorithm.
    Return a JSON array where each object has "title", "description", and "tags" (array of strings).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["title", "description", "tags"]
        }
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Empty response");
  return JSON.parse(text);
};

export const generateViralHashtags = async (prompt: string, platform: HashtagPlatform): Promise<string[]> => {
  const ai = getAI();
  const model = "gemini-3-flash-preview";

  const response = await ai.models.generateContent({
    model,
    contents: `Generate 20 viral, trending, and high-reach hashtags for a ${platform} post about: "${prompt}". 
    Ensure hashtags are optimized for ${platform}'s specific discovery algorithm.
    Return just the JSON array of strings.`,
    config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
        }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Empty response");
  return JSON.parse(text);
};