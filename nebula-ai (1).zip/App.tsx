import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { User, AppSettings } from './types';
import { getCurrentUser, getSettings, saveSettings } from './services/storageService';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import HistoryPage from './pages/HistoryPage';
import SettingsPage from './pages/SettingsPage';

// --- Auth Context ---
interface AuthContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  isLoading: boolean;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  setUser: () => {},
  isLoading: true,
  theme: 'light',
  toggleTheme: () => {}
});

export const useAuth = () => useContext(AuthContext);

// --- Protected Route Wrapper ---
const ProtectedRoute: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center dark:bg-dark-bg text-gray-500">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

// --- App Component ---
export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Initialize Auth & Theme
  useEffect(() => {
    // Check for an active, valid session from storage
    const storedUser = getCurrentUser();
    
    if (storedUser) {
      setUser(storedUser);
      // Load user preferences
      const settings = getSettings(storedUser.id);
      setTheme(settings.theme);
    } else {
        // Fallback: Check system preference if no user preference
       if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
         setTheme('dark');
       }
    }
    
    // Auth check complete
    setIsLoading(false);
  }, []);

  // Update HTML class for Tailwind Dark Mode
  useEffect(() => {
    const html = document.documentElement;
    if (theme === 'dark') {
      html.classList.add('dark');
    } else {
      html.classList.remove('dark');
    }
    // Persist theme if user is logged in
    if (user) {
        saveSettings({ userId: user.id, theme });
    }
  }, [theme, user]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <AuthContext.Provider value={{ user, setUser, isLoading, theme, toggleTheme }}>
      <HashRouter>
        <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-dark-bg text-gray-900 dark:text-dark-text transition-colors duration-300">
           <ConditionalNavbar />
           <main className="flex-grow">
             <Routes>
               <Route path="/" element={<LandingPage />} />
               <Route path="/login" element={<AuthPage />} />
               <Route path="/signup" element={<AuthPage isSignup />} />
               
               {/* Protected Routes */}
               <Route path="/dashboard" element={
                 <ProtectedRoute>
                   <Dashboard />
                 </ProtectedRoute>
               } />
               <Route path="/history" element={
                 <ProtectedRoute>
                   <HistoryPage />
                 </ProtectedRoute>
               } />
               <Route path="/settings" element={
                 <ProtectedRoute>
                   <SettingsPage />
                 </ProtectedRoute>
               } />
               
               <Route path="*" element={<Navigate to="/" replace />} />
             </Routes>
           </main>
        </div>
      </HashRouter>
    </AuthContext.Provider>
  );
}

// Helper to hide navbar on login pages if desired, but request says "Top navigation bar" generally available.
// However, typically dashboard apps have a different nav or sidebar. 
// Let's make a smart navbar that adapts.
const ConditionalNavbar = () => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/login' || location.pathname === '/signup';
  
  // Show Navbar everywhere, it adapts content based on auth state
  return <Navbar />; 
};