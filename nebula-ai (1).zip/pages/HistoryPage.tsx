import React, { useEffect, useState } from 'react';
import { useAuth } from '../App';
import { getHistory, deleteHistoryItem, clearUserHistory } from '../services/storageService';
import { HistoryItem, ToolType } from '../types';
import { Trash2, Calendar, Image, Search, Hash, Copy, Check, Download, Eye, X, AlertCircle } from 'lucide-react';

const HistoryPage: React.FC = () => {
  const { user } = useAuth();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [filter, setFilter] = useState<ToolType | 'ALL'>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Notification State
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    const loadHistory = async () => {
      if (user) {
        setIsLoading(true);
        try {
          const data = await getHistory(user.id);
          setHistory(data);
        } catch (error) {
          console.error("Failed to load history", error);
        } finally {
          setIsLoading(false);
        }
      }
    };
    loadHistory();
  }, [user]);

  // Auto-hide notification
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to permanently delete this item?")) {
        // Optimistic UI update: Remove item immediately
        const previousHistory = [...history];
        setHistory(prev => prev.filter(item => item.id !== id));

        try {
          // Perform DB deletion
          await deleteHistoryItem(id);
          
          // Show success message
          setNotification({ type: 'success', message: 'Item deleted permanently.' });
          
        } catch (error) {
          console.error("Delete failed", error);
          
          // Revert UI if failed
          setHistory(previousHistory);
          setNotification({ type: 'error', message: 'Failed to delete. Please try again.' });
        }
    }
  };

  const handleClearAll = async () => {
    if (history.length === 0) return;
    
    if (window.confirm("Are you sure you want to delete ALL history? This action cannot be undone.")) {
      try {
        if (user) {
          await clearUserHistory(user.id);
          setHistory([]);
          setNotification({ type: 'success', message: 'All history cleared successfully.' });
        }
      } catch (error) {
        console.error("Clear all failed", error);
        setNotification({ type: 'error', message: 'Failed to clear history.' });
      }
    }
  };

  const handleDownload = (imageUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `nebula-history-${Date.now()}-${index}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredHistory = filter === 'ALL' ? history : history.filter(h => h.tool === filter);

  const getIcon = (tool: ToolType) => {
    switch (tool) {
      case ToolType.TEXT_TO_IMAGE: return Image;
      case ToolType.YOUTUBE_SEO: return Search;
      case ToolType.VIRAL_HASHTAGS: return Hash;
      default: return Image;
    }
  };

  const getToolLabel = (item: HistoryItem) => {
      if (item.tool === ToolType.YOUTUBE_SEO) {
          return item.options?.platform ? `${item.options.platform} SEO` : 'YouTube SEO';
      }
      if (item.tool === ToolType.VIRAL_HASHTAGS) {
          return item.options?.platform ? `${item.options.platform} Hashtags` : 'Viral Hashtags';
      }
      return 'Text to Image';
  };

  const copyResult = (item: HistoryItem) => {
    let text = "";
    if (item.tool === ToolType.YOUTUBE_SEO) {
        const res = item.result as any[];
        text = res.map(r => `${r.title}\n${r.description}`).join('\n\n');
    } else if (item.tool === ToolType.VIRAL_HASHTAGS) {
        text = (item.result as string[]).join(' ');
    } else {
        return; 
    }
    
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Loading history...
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 min-h-screen relative">
      
      {/* Notification Toast */}
      {notification && (
        <div className={`fixed top-24 right-4 z-50 px-4 py-3 rounded-lg shadow-lg flex items-center space-x-2 animate-fade-in border ${
          notification.type === 'success' 
            ? 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800' 
            : 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800'
        }`}>
          {notification.type === 'success' ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          <span className="font-medium text-sm">{notification.message}</span>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-end md:items-center mb-8 gap-4">
        <div>
           <h1 className="text-3xl font-bold text-gray-900 dark:text-white">History</h1>
           <p className="text-gray-500 dark:text-gray-400">Your creative archive.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-end sm:items-center gap-4">
          {history.length > 0 && (
             <button 
               onClick={handleClearAll}
               className="flex items-center px-4 py-2 text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors dark:bg-red-900/20 dark:text-red-400 dark:hover:bg-red-900/30 border border-red-200 dark:border-red-900/50"
             >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
             </button>
          )}

          <div className="flex bg-white dark:bg-[#131620] rounded-lg p-1 shadow-sm border border-gray-200 dark:border-gray-800">
            <FilterBtn active={filter === 'ALL'} onClick={() => setFilter('ALL')} label="All" />
            <FilterBtn active={filter === ToolType.TEXT_TO_IMAGE} onClick={() => setFilter(ToolType.TEXT_TO_IMAGE)} label="Images" />
            <FilterBtn active={filter === ToolType.YOUTUBE_SEO} onClick={() => setFilter(ToolType.YOUTUBE_SEO)} label="SEO" />
            <FilterBtn active={filter === ToolType.VIRAL_HASHTAGS} onClick={() => setFilter(ToolType.VIRAL_HASHTAGS)} label="Hashtags" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredHistory.length === 0 ? (
          <div className="col-span-full py-20 text-center rounded-2xl border-2 border-dashed border-gray-200 dark:border-gray-800">
             <div className="inline-flex p-4 rounded-full bg-gray-100 dark:bg-gray-800 mb-4">
               <HistoryIcon className="w-8 h-8 text-gray-400" />
             </div>
             <p className="text-gray-500 dark:text-gray-400 font-medium">No history items found.</p>
          </div>
        ) : (
          filteredHistory.map((item) => {
            const Icon = getIcon(item.tool);
            return (
              <div key={item.id} className="group bg-white dark:bg-[#131620] rounded-2xl shadow-sm hover:shadow-xl border border-gray-200 dark:border-gray-800 flex flex-col transition-all duration-300 overflow-hidden">
                
                {/* Header */}
                <div className="p-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-white/5 flex justify-between items-center">
                   <div className="flex items-center space-x-2">
                      <div className={`p-1.5 rounded-md ${
                        item.tool === ToolType.TEXT_TO_IMAGE ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' : 
                        item.tool === ToolType.YOUTUBE_SEO ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' :
                        'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-semibold text-gray-700 dark:text-gray-200">{getToolLabel(item)}</span>
                   </div>
                   <span className="text-xs text-gray-400 flex items-center">
                      <Calendar className="w-3 h-3 mr-1" />
                      {new Date(item.timestamp).toLocaleDateString()}
                   </span>
                </div>

                {/* Content */}
                <div className="p-5 flex-1 flex flex-col">
                  <p className="text-sm text-gray-900 dark:text-white font-medium line-clamp-2 mb-4">
                    "{item.prompt}"
                  </p>
                  
                  <div className="mt-auto">
                     {item.tool === ToolType.TEXT_TO_IMAGE && (
                       <div className="grid grid-cols-2 gap-2">
                         {(item.result as string[]).slice(0, 2).map((src, i) => (
                           <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-gray-100 dark:bg-black group/img">
                             <img src={src} className="h-full w-full object-cover" alt="Gen" />
                             <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center space-x-2">
                                <button onClick={() => setSelectedImage(src)} className="p-1.5 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-sm"><Eye className="w-4 h-4" /></button>
                                <button onClick={() => handleDownload(src, i)} className="p-1.5 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-sm"><Download className="w-4 h-4" /></button>
                             </div>
                           </div>
                         ))}
                       </div>
                     )}
                     
                     {item.tool === ToolType.YOUTUBE_SEO && (
                       <div className="text-xs text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-white/5 p-3 rounded-lg border border-gray-100 dark:border-gray-800">
                          <p className="font-bold text-gray-900 dark:text-white mb-1 truncate">{(item.result[0] as any).title}</p>
                          <p className="line-clamp-2 opacity-80">{(item.result[0] as any).description}</p>
                       </div>
                     )}
                     
                     {item.tool === ToolType.VIRAL_HASHTAGS && (
                        <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-900/10 border border-purple-100 dark:border-purple-900/20">
                           <p className="text-xs text-purple-700 dark:text-purple-300 line-clamp-3 leading-relaxed">
                              {(item.result as string[]).map(t => (t.startsWith('#') ? t : `#${t}`)).join(' ')}
                           </p>
                        </div>
                     )}
                  </div>
                </div>

                {/* Footer Actions */}
                <div className="p-3 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2 bg-gray-50/30 dark:bg-white/[0.02]">
                  {item.tool !== ToolType.TEXT_TO_IMAGE && (
                    <button 
                      onClick={() => copyResult(item)}
                      className="flex items-center px-3 py-1.5 rounded-lg text-xs font-medium text-gray-600 dark:text-gray-400 hover:bg-white dark:hover:bg-white/10 hover:shadow-sm transition-all border border-transparent hover:border-gray-200 dark:hover:border-gray-700"
                    >
                      {copiedId === item.id ? <Check className="w-3 h-3 mr-1.5 text-green-500" /> : <Copy className="w-3 h-3 mr-1.5" />}
                      {copiedId === item.id ? 'Copied' : 'Copy Result'}
                    </button>
                  )}
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="flex items-center px-3 py-1.5 rounded-lg text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
                  >
                    <Trash2 className="w-3 h-3 mr-1.5" />
                    Delete
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Full Screen Image Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4" onClick={() => setSelectedImage(null)}>
           <div className="relative max-w-5xl w-full flex flex-col items-center animate-fade-in">
             <img src={selectedImage} alt="Full View" className="max-w-full max-h-[85vh] rounded-lg shadow-2xl mb-4 border border-gray-800" />
             
             <div className="flex gap-4" onClick={(e) => e.stopPropagation()}>
                <button 
                  onClick={() => handleDownload(selectedImage, 1)}
                  className="flex items-center px-6 py-2 bg-white text-black rounded-full font-medium hover:bg-gray-200 transition-colors"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </button>
                 <button 
                   onClick={() => setSelectedImage(null)}
                   className="flex items-center px-6 py-2 bg-gray-800 text-white rounded-full font-medium hover:bg-gray-700 transition-colors border border-gray-700"
                 >
                   <X className="w-4 h-4 mr-2" />
                   Close
                 </button>
             </div>
           </div>
        </div>
      )}
    </div>
  );
};

const HistoryIcon = (props: any) => (
    <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const FilterBtn = ({ active, onClick, label }: any) => (
  <button 
    onClick={onClick}
    className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
      active 
      ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm ring-1 ring-gray-200 dark:ring-gray-600' 
      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
    }`}
  >
    {label}
  </button>
);

export default HistoryPage;