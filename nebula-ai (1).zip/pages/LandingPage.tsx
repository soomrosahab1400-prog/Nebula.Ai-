import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Image as ImageIcon, Hash, BarChart3, ChevronRight } from 'lucide-react';

const LandingPage: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-white dark:bg-[#0B0F19] transition-colors duration-300 overflow-hidden font-sans">
      
      {/* Background Gradients */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-500/20 rounded-full blur-[120px] mix-blend-multiply dark:mix-blend-screen animate-pulse-slow"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/20 rounded-full blur-[120px] mix-blend-multiply dark:mix-blend-screen animate-pulse-slow delay-1000"></div>
        <div className="absolute top-[20%] right-[20%] w-[20%] h-[20%] bg-cyan-500/10 rounded-full blur-[80px] mix-blend-multiply dark:mix-blend-screen"></div>
      </div>

      <div className="relative z-10">
        
        {/* Hero Section */}
        <section className="pt-24 pb-20 sm:pt-32 sm:pb-24 lg:pb-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-sm text-gray-600 dark:text-gray-300 mb-8 hover:bg-gray-200 dark:hover:bg-white/10 transition-colors cursor-default">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span className="font-medium">Now with Gemini 2.5 Flash</span>
            <ChevronRight className="w-3 h-3 opacity-50" />
          </div>

          {/* Headline */}
          <h1 className="text-5xl sm:text-7xl font-bold tracking-tight text-gray-900 dark:text-white mb-8 leading-tight">
            The Ultimate AI Suite for <br className="hidden sm:block" />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 dark:from-blue-400 dark:via-purple-400 dark:to-pink-400">
              Modern Creators
            </span>
          </h1>

          {/* Subheadline */}
          <p className="max-w-2xl mx-auto text-lg sm:text-xl text-gray-600 dark:text-gray-400 mb-10 leading-relaxed">
            Generate stunning visuals, optimize your content for SEO, and discover viral hashtags. 
            All the tools you need to grow, in one professional dashboard.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20">
            <Link
              to="/signup"
              className="w-full sm:w-auto px-8 py-4 rounded-full bg-gray-900 dark:bg-white text-white dark:text-gray-900 font-semibold hover:scale-105 active:scale-95 transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
            >
              Start Creating
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/login"
              className="w-full sm:w-auto px-8 py-4 rounded-full bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-700 dark:text-white font-semibold hover:bg-gray-50 dark:hover:bg-white/10 transition-all duration-200 flex items-center justify-center"
            >
              Login
            </Link>
          </div>

          {/* Dashboard Preview (Mock UI) */}
          <div className="relative mx-auto max-w-5xl px-2 sm:px-0">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl blur opacity-20 dark:opacity-30"></div>
            <div className="relative rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-[#131620] shadow-2xl overflow-hidden">
              
              {/* Window Controls */}
              <div className="h-10 border-b border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#1A1F2E] flex items-center px-4 gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                
                {/* Fake URL Bar */}
                <div className="ml-4 flex-1 max-w-md mx-auto h-6 bg-gray-200 dark:bg-black/20 rounded-md flex items-center justify-center text-[10px] text-gray-500 dark:text-gray-400 font-mono">
                  nebula-ai.com/dashboard
                </div>
              </div>

              {/* Mock App Content */}
              <div className="flex h-[300px] sm:h-[400px] md:h-[500px]">
                {/* Fake Sidebar */}
                <div className="hidden md:flex w-60 border-r border-gray-200 dark:border-gray-800 p-4 flex-col gap-4 bg-gray-50/50 dark:bg-[#131620]">
                   <div className="h-8 w-24 bg-gray-200 dark:bg-white/10 rounded-md mb-4"></div>
                   <div className="space-y-2">
                     <div className="h-10 w-full bg-blue-500/10 text-blue-500 rounded-lg flex items-center px-3 text-sm font-medium border border-blue-500/20">
                        <ImageIcon className="w-4 h-4 mr-2" />
                        Text to Image
                     </div>
                     <div className="h-10 w-full hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg flex items-center px-3 text-sm text-gray-500 dark:text-gray-400">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        YouTube SEO
                     </div>
                     <div className="h-10 w-full hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg flex items-center px-3 text-sm text-gray-500 dark:text-gray-400">
                        <Hash className="w-4 h-4 mr-2" />
                        Hashtags
                     </div>
                   </div>
                   <div className="mt-auto h-24 rounded-lg bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/20 p-3">
                      <div className="h-2 w-12 bg-purple-500/40 rounded mb-2"></div>
                      <div className="h-1 w-full bg-gray-200 dark:bg-white/10 rounded"></div>
                   </div>
                </div>

                {/* Fake Main Area */}
                <div className="flex-1 p-6 flex flex-col">
                  {/* Fake Header */}
                  <div className="flex justify-between items-center mb-8">
                     <div className="h-6 w-32 bg-gray-200 dark:bg-white/10 rounded"></div>
                     <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-white/10"></div>
                  </div>

                  {/* Fake Input */}
                  <div className="w-full h-32 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-[#0B0F19] p-4 mb-6 relative">
                     <div className="h-4 w-3/4 bg-gray-200 dark:bg-white/10 rounded mb-2"></div>
                     <div className="h-4 w-1/2 bg-gray-200 dark:bg-white/10 rounded"></div>
                     <div className="absolute bottom-4 right-4 h-8 w-24 bg-blue-600 rounded-lg shadow-lg shadow-blue-500/20 flex items-center justify-center">
                        <div className="h-4 w-12 bg-white/20 rounded"></div>
                     </div>
                  </div>

                  {/* Fake Results Grid */}
                  <div className="grid grid-cols-3 gap-4 h-full">
                     <div className="rounded-lg bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5 relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="absolute bottom-2 left-2 right-2 h-2 bg-gray-200 dark:bg-white/10 rounded"></div>
                     </div>
                     <div className="rounded-lg bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5 relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 opacity-0"></div>
                        <div className="absolute bottom-2 left-2 right-2 h-2 bg-gray-200 dark:bg-white/10 rounded"></div>
                     </div>
                     <div className="rounded-lg bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5 relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br from-orange-500/20 to-red-500/20 opacity-0"></div>
                        <div className="absolute bottom-2 left-2 right-2 h-2 bg-gray-200 dark:bg-white/10 rounded"></div>
                     </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 relative bg-gray-50 dark:bg-[#0B0F19]/50 border-t border-gray-100 dark:border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
               <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Powerful Features</h2>
               <p className="text-gray-500 dark:text-gray-400 text-lg">Everything you need to create content that stands out in the crowded digital space.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
               <FeatureCard 
                 icon={ImageIcon} 
                 title="AI Image Generation" 
                 desc="Create photorealistic images from text descriptions with our advanced Gemini-powered engine."
                 gradient="from-blue-500 to-cyan-500"
               />
               <FeatureCard 
                 icon={BarChart3} 
                 title="Smart SEO Optimization" 
                 desc="Get tailored titles, descriptions, and tags for YouTube, TikTok, and Blogs to maximize reach."
                 gradient="from-purple-500 to-pink-500"
               />
               <FeatureCard 
                 icon={Hash} 
                 title="Viral Hashtag Strategy" 
                 desc="Generate platform-specific trending hashtags to boost your discoverability instantly."
                 gradient="from-orange-500 to-red-500"
               />
            </div>
          </div>
        </section>

        {/* Footer / CTA */}
        <section className="py-20 border-t border-gray-200 dark:border-white/5 bg-white dark:bg-[#131620]">
           <div className="max-w-4xl mx-auto px-4 text-center">
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Ready to transform your content?</h2>
              <Link 
                to="/signup" 
                className="inline-flex px-8 py-4 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold text-lg hover:shadow-xl hover:scale-105 transition-all"
              >
                Get Started for Free
              </Link>
              <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">No credit card required • Free tier available</p>
           </div>
        </section>

      </div>
    </div>
  );
};

const FeatureCard = ({ icon: Icon, title, desc, gradient }: any) => (
  <div className="group p-8 rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 hover:border-transparent hover:ring-2 hover:ring-blue-500/50 transition-all duration-300">
    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center mb-6 shadow-lg transform group-hover:scale-110 transition-transform duration-300`}>
       <Icon className="w-7 h-7 text-white" />
    </div>
    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{title}</h3>
    <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
      {desc}
    </p>
  </div>
);

export default LandingPage;