import React, { useState, useRef } from 'react';
import { useAuth } from '../App';
import { ToolType, AspectRatio, LIMITS, HashtagPlatform, SeoPlatform } from '../types';
import { checkLimit, incrementUsage, saveHistoryItem } from '../services/storageService';
import { generateImages, generateSEO, generateViralHashtags } from '../services/geminiService';
import { Wand2, Image, Search, Hash, Upload, X, Copy, Check, Download, ExternalLink, Zap } from 'lucide-react';

const HASHTAG_PLATFORMS: HashtagPlatform[] = [
  'Instagram', 'TikTok', 'YouTube', 'Facebook', 'Twitter (X)', 'Threads', 'LinkedIn', 'Pinterest', 'Snapchat'
];

const SEO_PLATFORMS: SeoPlatform[] = [
  'YouTube', 'TikTok', 'Instagram', 'Website / Blog', 'E-commerce', 'Podcast', 'Facebook Pages'
];

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [selectedTool, setSelectedTool] = useState<ToolType>(ToolType.TEXT_TO_IMAGE);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Tool Specific Options
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(AspectRatio.RATIO_1_1);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  
  // Platform States
  const [hashtagPlatform, setHashtagPlatform] = useState<HashtagPlatform>('Instagram');
  const [seoPlatform, setSeoPlatform] = useState<SeoPlatform>('YouTube');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Results
  const [results, setResults] = useState<any>(null); // Flexible type for diff tools
  
  // UI State
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleToolChange = (tool: ToolType) => {
    setSelectedTool(tool);
    setResults(null);
    setError(null);
    setPrompt('');
    setReferenceImage(null);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownload = (imageUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `nebula-ai-gen-${Date.now()}-${index}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerate = async () => {
    if (!user) return;
    if (!prompt.trim()) {
      setError("Please enter a prompt.");
      return;
    }
    
    // 1. Check Limits
    const canProceed = checkLimit(user.id, selectedTool);
    if (!canProceed) {
      setError("Daily limit reached for this tool. Please try again tomorrow.");
      return;
    }

    setIsGenerating(true);
    setError(null);
    setResults(null);

    try {
      let output: any;
      let options: any = {};

      if (selectedTool === ToolType.TEXT_TO_IMAGE) {
        output = await generateImages(prompt, aspectRatio, referenceImage || undefined);
        options = { aspectRatio, referenceImage };
      } else if (selectedTool === ToolType.YOUTUBE_SEO) {
        output = await generateSEO(prompt, seoPlatform);
        options = { platform: seoPlatform };
      } else if (selectedTool === ToolType.VIRAL_HASHTAGS) {
        output = await generateViralHashtags(prompt, hashtagPlatform);
        options = { platform: hashtagPlatform };
      }

      // 2. Increment Usage
      incrementUsage(user.id, selectedTool);

      // 3. Save History (Async)
      await saveHistoryItem({
        id: Date.now().toString(),
        userId: user.id,
        tool: selectedTool,
        prompt: prompt,
        result: output,
        options: options,
        timestamp: Date.now()
      });

      setResults(output);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const getInputLabel = () => {
    switch (selectedTool) {
        case ToolType.TEXT_TO_IMAGE: return "Describe your imagination";
        case ToolType.YOUTUBE_SEO: return `What is your ${seoPlatform} video about?`;
        case ToolType.VIRAL_HASHTAGS: return `Topic for ${hashtagPlatform} post`;
        default: return "Enter prompt";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50/50 dark:bg-[#0B0F19] transition-colors duration-300">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {/* Header */}
        <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Create New</h1>
            <p className="text-gray-500 dark:text-gray-400">Unleash your creativity with AI.</p>
          </div>
          <div className="flex items-center space-x-2 bg-white dark:bg-white/5 px-4 py-2 rounded-full border border-gray-200 dark:border-white/10 shadow-sm">
             <Zap className="w-4 h-4 text-yellow-500 fill-current" />
             <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
               {user ? LIMITS[selectedTool] - (user ? 0 : 0) : 0} credits left
             </span>
          </div>
        </div>

        {/* 1. Tool Selector - Top Row */}
        <div className="mb-8 bg-white dark:bg-[#131620] p-1.5 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm flex overflow-x-auto">
          <ToolTab 
            active={selectedTool === ToolType.TEXT_TO_IMAGE} 
            onClick={() => handleToolChange(ToolType.TEXT_TO_IMAGE)}
            label="Text to Image"
            icon={Image}
          />
          <ToolTab 
            active={selectedTool === ToolType.YOUTUBE_SEO} 
            onClick={() => handleToolChange(ToolType.YOUTUBE_SEO)}
            label="SEO Optimizer"
            icon={Search}
          />
          <ToolTab 
            active={selectedTool === ToolType.VIRAL_HASHTAGS} 
            onClick={() => handleToolChange(ToolType.VIRAL_HASHTAGS)}
            label="Viral Hashtags"
            icon={Hash}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Input Area */}
          <div className="lg:col-span-8 space-y-8">
             
             <div className="bg-white dark:bg-[#131620] rounded-2xl shadow-xl shadow-gray-200/50 dark:shadow-none border border-gray-100 dark:border-gray-800 overflow-hidden">
               {/* 2. Prompt Input - Always First */}
               <div className="p-6 border-b border-gray-100 dark:border-gray-800">
                  <label className="block text-sm font-bold text-gray-700 dark:text-gray-200 mb-3">
                    {getInputLabel()}
                  </label>
                  <div className="relative group">
                    <textarea
                      className="w-full h-32 p-4 rounded-xl bg-gray-50 dark:bg-[#0B0F19] border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none transition-all text-base placeholder:text-gray-400"
                      placeholder="Start typing here..."
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                    ></textarea>
                    <div className="absolute bottom-3 right-3 text-xs text-gray-400 bg-white/50 dark:bg-black/50 px-2 py-1 rounded-md backdrop-blur-sm pointer-events-none">
                       {prompt.length} chars
                    </div>
                  </div>
               </div>

               {/* 3. Configuration - Based on Tool */}
               <div className="p-6 bg-gray-50/50 dark:bg-white/5">
                 {selectedTool === ToolType.TEXT_TO_IMAGE && (
                    <div className="space-y-6 animate-fade-in">
                       {/* Reference Image */}
                       <div>
                          <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3 block">Reference Image Style</label>
                          {!referenceImage ? (
                            <div 
                              onClick={() => fileInputRef.current?.click()}
                              className="group border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-blue-500 dark:hover:border-blue-500 rounded-xl p-4 text-center cursor-pointer transition-all duration-200 bg-white dark:bg-[#0B0F19]"
                            >
                               <div className="flex items-center justify-center space-x-2">
                                 <Upload className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                                 <span className="text-sm font-medium text-gray-600 dark:text-gray-300 group-hover:text-blue-600">Upload Reference Image</span>
                               </div>
                               <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                            </div>
                          ) : (
                            <div className="relative rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700 group w-full h-32">
                              <img src={referenceImage} alt="Ref" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                              <button 
                                onClick={() => setReferenceImage(null)}
                                className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-red-500 backdrop-blur-sm rounded-full text-white transition-colors"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                       </div>

                       {/* Aspect Ratio */}
                       <div>
                          <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3 block">Aspect Ratio</label>
                          <div className="flex flex-wrap gap-2">
                            {Object.values(AspectRatio).map((ratio) => (
                              <button
                                key={ratio}
                                onClick={() => setAspectRatio(ratio)}
                                className={`px-4 py-2 text-sm font-medium rounded-lg border transition-all duration-200 ${
                                  aspectRatio === ratio 
                                  ? 'bg-white shadow-sm border-blue-500 text-blue-600 dark:bg-blue-600 dark:border-blue-600 dark:text-white' 
                                  : 'bg-white dark:bg-[#0B0F19] border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-gray-300 dark:hover:border-gray-600'
                                }`}
                              >
                                {ratio}
                              </button>
                            ))}
                          </div>
                       </div>
                    </div>
                 )}

                 {selectedTool === ToolType.YOUTUBE_SEO && (
                    <div className="animate-fade-in">
                       <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3 block">Target Platform</label>
                       <div className="relative">
                         <select 
                             value={seoPlatform}
                             onChange={(e) => setSeoPlatform(e.target.value as SeoPlatform)}
                             className="block w-full appearance-none rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#0B0F19] text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent py-3 px-4 pr-8"
                         >
                             {SEO_PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
                         </select>
                         <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-500">
                           <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" fillRule="evenodd"></path></svg>
                         </div>
                       </div>
                    </div>
                 )}

                 {selectedTool === ToolType.VIRAL_HASHTAGS && (
                    <div className="animate-fade-in">
                       <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3 block">Social Network</label>
                       <div className="relative">
                         <select 
                             value={hashtagPlatform}
                             onChange={(e) => setHashtagPlatform(e.target.value as HashtagPlatform)}
                             className="block w-full appearance-none rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#0B0F19] text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent py-3 px-4 pr-8"
                         >
                             {HASHTAG_PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
                         </select>
                         <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-500">
                           <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" fillRule="evenodd"></path></svg>
                         </div>
                       </div>
                    </div>
                 )}
               </div>

               {/* 4. Action Bar */}
               <div className="p-6 border-t border-gray-100 dark:border-gray-800 flex justify-end">
                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className={`w-full md:w-auto px-8 py-3 rounded-xl font-bold text-white shadow-lg shadow-blue-500/30 flex items-center justify-center transform transition-all duration-200 ${
                      isGenerating 
                        ? 'bg-gray-400 cursor-not-allowed' 
                        : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 hover:scale-[1.02] active:scale-[0.98]'
                    }`}
                  >
                    {isGenerating ? (
                       <>
                         <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                           <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                           <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                         </svg>
                         Creating...
                       </>
                    ) : (
                       <>
                         <Wand2 className="w-5 h-5 mr-2" />
                         Generate Content
                       </>
                    )}
                  </button>
               </div>
             </div>
             
             {error && (
               <div className="animate-fade-in p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-300 rounded-xl border border-red-100 dark:border-red-800 flex items-center">
                 <div className="w-2 h-2 bg-red-500 rounded-full mr-3"></div>
                 {error}
               </div>
             )}
          </div>

          {/* Results Area (Now in right column on large screens, or below on mobile) */}
          <div className="lg:col-span-4 space-y-6">
             {results ? (
               <div className="animate-fade-in space-y-6">
                  <div className="flex items-center space-x-2">
                     <h3 className="text-xl font-bold text-gray-900 dark:text-white">Generated Results</h3>
                  </div>

                  {selectedTool === ToolType.TEXT_TO_IMAGE && (
                    <div className="grid grid-cols-1 gap-4">
                      {(results as string[]).map((img, idx) => (
                        <div key={idx} className="group relative rounded-2xl overflow-hidden shadow-2xl bg-gray-900 aspect-square border border-gray-200 dark:border-gray-800">
                          <img 
                            src={img} 
                            alt={`Generated ${idx}`} 
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4">
                              <button 
                                  onClick={() => setSelectedImage(img)}
                                  className="p-3 bg-white/20 hover:bg-white/40 backdrop-blur-md rounded-full text-white transition-all"
                                  title="View"
                              >
                                  <ExternalLink className="w-5 h-5" />
                              </button>
                              <button 
                                  onClick={() => handleDownload(img, idx)}
                                  className="p-3 bg-white text-gray-900 hover:bg-gray-100 rounded-full transition-all shadow-lg"
                                  title="Download"
                              >
                                  <Download className="w-5 h-5" />
                              </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedTool === ToolType.YOUTUBE_SEO && (
                     <div className="space-y-4">
                       {(results as any[]).map((item, idx) => (
                         <div key={idx} className="bg-white dark:bg-[#131620] p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 relative">
                            <button 
                              onClick={() => copyToClipboard(`${item.title}\n${item.description}\n${item.tags.join(',')}`, idx)}
                              className="absolute top-4 right-4 text-gray-400 hover:text-blue-500"
                            >
                               {copiedIndex === idx ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                            </button>
                            
                            <h4 className="font-bold text-gray-900 dark:text-white mb-2 leading-tight pr-6">{item.title}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">{item.description}</p>
                            
                            <div className="flex flex-wrap gap-2">
                              {item.tags.slice(0, 5).map((tag: string, tIdx: number) => (
                                <span key={tIdx} className="bg-gray-100 dark:bg-white/10 text-gray-600 dark:text-gray-300 text-xs font-medium px-2 py-1 rounded">#{tag}</span>
                              ))}
                            </div>
                         </div>
                       ))}
                     </div>
                  )}

                  {selectedTool === ToolType.VIRAL_HASHTAGS && (
                    <div className="bg-white dark:bg-[#131620] p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 relative">
                       <button 
                          onClick={() => copyToClipboard((results as string[]).join(' '), 0)}
                          className="absolute top-4 right-4 text-gray-400 hover:text-purple-500"
                        >
                          {copiedIndex === 0 ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                        </button>
                        <h4 className="font-bold text-gray-900 dark:text-white mb-4">Hashtags</h4>
                        <div className="flex flex-wrap gap-2">
                           {(results as string[]).map((tag, idx) => (
                              <span key={idx} className="text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/10 px-2 py-1 rounded text-sm">
                                {tag.startsWith('#') ? tag : `#${tag}`}
                              </span>
                           ))}
                        </div>
                    </div>
                  )}
               </div>
             ) : (
               <div className="bg-white dark:bg-[#131620] rounded-2xl border border-dashed border-gray-300 dark:border-gray-700 p-8 text-center h-full min-h-[200px] flex flex-col items-center justify-center">
                  <div className="w-16 h-16 bg-gray-50 dark:bg-white/5 rounded-full flex items-center justify-center mb-4">
                    <SparklesIcon className="w-8 h-8 text-gray-300 dark:text-gray-600" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 font-medium">Your results will appear here</p>
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Full Screen Image Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 animate-fade-in" onClick={() => setSelectedImage(null)}>
           <div className="relative max-w-5xl w-full flex flex-col items-center">
             <img src={selectedImage} alt="Full View" className="max-w-full max-h-[85vh] rounded-lg shadow-2xl mb-6 ring-1 ring-white/10" />
             
             <div className="flex gap-4" onClick={(e) => e.stopPropagation()}>
                <button 
                  onClick={() => handleDownload(selectedImage, 1)}
                  className="flex items-center px-6 py-2 bg-white text-black rounded-full font-bold hover:bg-gray-200 transition-all shadow-lg"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </button>
                 <button 
                   onClick={() => setSelectedImage(null)}
                   className="flex items-center px-6 py-2 bg-white/10 text-white rounded-full font-bold hover:bg-white/20 transition-all backdrop-blur-md border border-white/10"
                 >
                   <X className="w-4 h-4 mr-2" />
                   Close
                 </button>
             </div>
           </div>
        </div>
      )}
    </div>
  );
};

const ToolTab = ({ active, onClick, label, icon: Icon }: any) => (
  <button
    onClick={onClick}
    className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
      active
        ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm ring-1 ring-gray-200 dark:ring-gray-700'
        : 'text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800/50 hover:text-gray-700 dark:hover:text-gray-200'
    }`}
  >
    <Icon className={`w-4 h-4 ${active ? 'text-blue-500' : 'opacity-70'}`} />
    <span>{label}</span>
  </button>
);

const SparklesIcon = (props: any) => (
    <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
);

export default Dashboard;
