import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../App';
import { loginUser, saveUser, updateSessionActivity } from '../services/storageService';
import { User } from '../types';
import { Mail, Lock, User as UserIcon, AlertCircle } from 'lucide-react';

interface Props {
  isSignup?: boolean;
}

const AuthPage: React.FC<Props> = ({ isSignup = false }) => {
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Simulate network delay for better UX
    await new Promise(resolve => setTimeout(resolve, 500));

    const email = formData.email.trim();
    const password = formData.password;
    const name = formData.name.trim();

    try {
      if (isSignup) {
        if (!name || !email || !password) {
          setError("All fields are required");
          setLoading(false);
          return;
        }

        if (password.length < 6) {
          setError("Password must be at least 6 characters");
          setLoading(false);
          return;
        }

        const newUser: User = {
          id: Date.now().toString(),
          name: name,
          email: email,
          password: password, // storageService will hash this
          createdAt: Date.now()
        };

        saveUser(newUser);
        
        // Auto login logic:
        // We manually set the session here because saveUser just saves to DB
        const loggedInUser = loginUser(email, password);
        if (loggedInUser) {
           setUser(loggedInUser);
           navigate('/dashboard');
        } else {
           // Should not happen theoretically
           setError("Account created but auto-login failed. Please sign in.");
           navigate('/login');
        }

      } else {
         const user = loginUser(email, password);
         if (user) {
           setUser(user);
           navigate('/dashboard');
         } else {
           setError("Invalid email or password. Please try again.");
         }
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-64px)] items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-dark-bg">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h2 className="mt-6 text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
            {isSignup ? "Create your account" : "Welcome back"}
          </h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {isSignup ? "Start your creative journey" : "Sign in to access your dashboard"}
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4 rounded-md shadow-sm">
            {isSignup && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  name="name"
                  type="text"
                  required
                  className="block w-full rounded-lg border border-gray-300 dark:border-dark-border pl-10 px-3 py-3 text-gray-900 dark:text-white dark:bg-dark-card placeholder-gray-500 focus:border-primary-500 focus:ring-primary-500 sm:text-sm transition-colors"
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </div>
            )}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                name="email"
                type="email"
                required
                className="block w-full rounded-lg border border-gray-300 dark:border-dark-border pl-10 px-3 py-3 text-gray-900 dark:text-white dark:bg-dark-card placeholder-gray-500 focus:border-primary-500 focus:ring-primary-500 sm:text-sm transition-colors"
                placeholder="Email address"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                name="password"
                type="password"
                required
                className="block w-full rounded-lg border border-gray-300 dark:border-dark-border pl-10 px-3 py-3 text-gray-900 dark:text-white dark:bg-dark-card placeholder-gray-500 focus:border-primary-500 focus:ring-primary-500 sm:text-sm transition-colors"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>
          </div>

          {error && (
            <div className="rounded-md bg-red-50 dark:bg-red-900/20 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-400" aria-hidden="true" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-800 dark:text-red-200">{error}</h3>
                </div>
              </div>
            </div>
          )}

          <div>
            <button
              type="submit"
              disabled={loading}
              className={`group relative flex w-full justify-center rounded-lg bg-primary-600 px-4 py-3 text-sm font-semibold text-white hover:bg-primary-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-600 transition-all shadow-lg shadow-primary-500/30 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {loading ? "Processing..." : (isSignup ? "Sign Up" : "Sign In")}
            </button>
          </div>
          
          <div className="text-center text-sm">
             <span className="text-gray-500 dark:text-gray-400">
               {isSignup ? "Already have an account?" : "Don't have an account?"}{' '}
             </span>
             <Link 
               to={isSignup ? "/login" : "/signup"} 
               className="font-medium text-primary-600 hover:text-primary-500 dark:text-primary-400"
             >
               {isSignup ? "Login here" : "Sign up now"}
             </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AuthPage;