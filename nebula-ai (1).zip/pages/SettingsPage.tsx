import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { saveUser, getUsage, logoutUser } from '../services/storageService';
import { LIMITS, UsageData, ToolType } from '../types';
import { Moon, Sun, User, Mail, Save, BarChart3, LogOut, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SettingsPage: React.FC = () => {
  const { user, setUser, theme, toggleTheme } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [usage, setUsage] = useState<UsageData | null>(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user) {
      setName(user.name);
      setEmail(user.email);
      setUsage(getUsage(user.id));
    }
  }, [user]);

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (user) {
      const updatedUser = { ...user, name, email };
      saveUser(updatedUser);
      setUser(updatedUser);
      setMessage("Profile updated successfully!");
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const handleLogout = () => {
    logoutUser();
    setUser(null);
    navigate('/login');
  }

  const getPercentage = (tool: ToolType) => {
    if (!usage) return 0;
    return Math.min(100, Math.round((usage.counts[tool] / LIMITS[tool]) * 100));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Account Settings</h1>
        <p className="text-gray-500 dark:text-gray-400">Manage your profile, preferences, and usage.</p>
      </div>

      <div className="grid gap-6">
        
        {/* Section 1: Profile */}
        <div className="bg-white dark:bg-[#131620] rounded-2xl shadow-sm border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-white/5 flex items-center">
            <User className="w-5 h-5 mr-3 text-blue-500" />
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Profile Information</h2>
          </div>
          
          <div className="p-6">
            <form onSubmit={handleUpdateProfile} className="space-y-6">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Full Name</label>
                   <div className="relative group">
                     <User className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                     <input 
                       type="text" 
                       value={name} 
                       onChange={(e) => setName(e.target.value)}
                       className="pl-10 block w-full rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#0B0F19] py-2.5 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                     />
                   </div>
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Email Address</label>
                   <div className="relative group">
                     <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                     <input 
                       type="email" 
                       value={email} 
                       onChange={(e) => setEmail(e.target.value)}
                       className="pl-10 block w-full rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#0B0F19] py-2.5 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                     />
                   </div>
                 </div>
               </div>
               
               <div className="flex items-center justify-between pt-2">
                  <p className="text-green-600 text-sm font-medium animate-fade-in">{message}</p>
                  <button 
                    type="submit"
                    className="flex items-center px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium shadow-lg shadow-blue-500/20 transition-all active:scale-95"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </button>
               </div>
            </form>
          </div>
        </div>

        {/* Section 2: Preferences */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-[#131620] rounded-2xl shadow-sm border border-gray-200 dark:border-gray-800 overflow-hidden flex flex-col">
              <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-white/5 flex items-center">
                {theme === 'dark' ? <Moon className="w-5 h-5 mr-3 text-purple-500" /> : <Sun className="w-5 h-5 mr-3 text-orange-500" />}
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Appearance</h2>
              </div>
              <div className="p-6 flex items-center justify-between flex-1">
                <div>
                  <p className="text-gray-900 dark:text-white font-medium">Dark Mode</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Easier on the eyes at night.</p>
                </div>
                <button 
                   onClick={toggleTheme}
                   className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${theme === 'dark' ? 'bg-blue-600' : 'bg-gray-200'}`}
                >
                  <span className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${theme === 'dark' ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
              </div>
            </div>

            <div className="bg-white dark:bg-[#131620] rounded-2xl shadow-sm border border-gray-200 dark:border-gray-800 overflow-hidden flex flex-col">
              <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-white/5 flex items-center">
                <Shield className="w-5 h-5 mr-3 text-red-500" />
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Session</h2>
              </div>
              <div className="p-6 flex items-center justify-between flex-1">
                <div>
                  <p className="text-gray-900 dark:text-white font-medium">Sign Out</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">End your current session safely.</p>
                </div>
                <button 
                   onClick={handleLogout}
                   className="px-4 py-2 border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-sm font-medium flex items-center"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </button>
              </div>
            </div>
        </div>

        {/* Section 3: Usage */}
        <div className="bg-white dark:bg-[#131620] rounded-2xl shadow-sm border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-white/5 flex items-center">
            <BarChart3 className="w-5 h-5 mr-3 text-green-500" />
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Usage Statistics</h2>
          </div>
          
          <div className="p-8 space-y-8">
            <UsageBar 
              label="Text to Image Generations" 
              current={usage?.counts[ToolType.TEXT_TO_IMAGE] || 0} 
              max={LIMITS[ToolType.TEXT_TO_IMAGE]} 
              percent={getPercentage(ToolType.TEXT_TO_IMAGE)}
              color="bg-blue-500"
            />
            <UsageBar 
              label="SEO Optimizations" 
              current={usage?.counts[ToolType.YOUTUBE_SEO] || 0} 
              max={LIMITS[ToolType.YOUTUBE_SEO]} 
              percent={getPercentage(ToolType.YOUTUBE_SEO)}
              color="bg-red-500"
            />
            <UsageBar 
              label="Hashtag Generations" 
              current={usage?.counts[ToolType.VIRAL_HASHTAGS] || 0} 
              max={LIMITS[ToolType.VIRAL_HASHTAGS]} 
              percent={getPercentage(ToolType.VIRAL_HASHTAGS)}
              color="bg-purple-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const UsageBar = ({ label, current, max, percent, color }: any) => (
  <div>
    <div className="flex justify-between mb-2">
      <span className="text-sm font-bold text-gray-700 dark:text-gray-200">{label}</span>
      <span className="text-sm font-medium text-gray-500 dark:text-gray-400">{current} / {max} used</span>
    </div>
    <div className="w-full bg-gray-100 dark:bg-gray-800 rounded-full h-3 overflow-hidden">
      <div 
        className={`h-full rounded-full ${color} transition-all duration-1000 ease-out`} 
        style={{ width: `${percent}%` }}
      ></div>
    </div>
  </div>
);

export default SettingsPage;
